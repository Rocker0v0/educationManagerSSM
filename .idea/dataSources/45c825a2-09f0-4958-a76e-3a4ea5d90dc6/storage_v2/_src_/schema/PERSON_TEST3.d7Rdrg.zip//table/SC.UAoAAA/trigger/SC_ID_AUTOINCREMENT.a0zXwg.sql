create trigger SC_ID_AUTOINCREMENT
    before insert
    on SC
    for each row
    when (new.PARIMARYID is null)
begin
 select sc_id_sequence.nextval into: new.PARIMARYID from dual;
 end;
/

