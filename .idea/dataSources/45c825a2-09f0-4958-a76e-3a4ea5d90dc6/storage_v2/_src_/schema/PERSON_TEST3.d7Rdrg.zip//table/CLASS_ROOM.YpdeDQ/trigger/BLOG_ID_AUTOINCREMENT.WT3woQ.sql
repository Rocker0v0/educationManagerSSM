create trigger BLOG_ID_AUTOINCREMENT
    before insert
    on CLASS_ROOM
    for each row
    when (new.CLASSROOM_ID is null)
begin
 select blog_id_sequence.nextval into: new.CLASSROOM_ID from dual;
 end;
/

