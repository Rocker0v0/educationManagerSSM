create trigger STUDENTDELBYCLASS
    before delete
    on CLASS
    for each row
begin
 delete from students where class_id= :old.class_id;
 end;
/

