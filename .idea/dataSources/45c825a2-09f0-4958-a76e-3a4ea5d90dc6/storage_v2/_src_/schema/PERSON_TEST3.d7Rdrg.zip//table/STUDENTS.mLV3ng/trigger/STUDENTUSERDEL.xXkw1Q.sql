create trigger STUDENTUSERDEL
    after delete
    on STUDENTS
    for each row
begin
 delete from stu_user where suser = :old.student_id;
 end;
/

