create trigger DELSCBYSTUDENT
    before delete
    on STUDENTS
    for each row
begin
delete from SC where sc.student_id = :old.student_id;
end;
/

