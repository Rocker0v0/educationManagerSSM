create trigger TC_ID_AUTOINCREMENT
    before insert
    on TC
    for each row
    when (new.id is null)
begin
 select tc_id_sequence.nextval into: new.id from dual;
 end;
/

