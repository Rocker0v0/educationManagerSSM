create trigger STUDENTUSER
    after insert
    on STUDENTS
    for each row
begin
 insert into stu_user values(:new.student_id,123456);
 end;
/

