create trigger TEACHER_ID_AUTOINCREMENT
    before insert
    on TEACHER
    for each row
    when (new.teacher_id is null)
begin
 select teacher_id_sequence.nextval into: new.teacher_id from dual;
 end;
/

