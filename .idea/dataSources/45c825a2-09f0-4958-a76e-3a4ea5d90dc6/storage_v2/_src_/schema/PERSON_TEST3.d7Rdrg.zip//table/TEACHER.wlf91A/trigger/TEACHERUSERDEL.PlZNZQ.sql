create trigger TEACHERUSERDEL
    after delete
    on TEACHER
    for each row
begin
 delete from tea_user where tuser = :old.teacher_id;
 end;
/

