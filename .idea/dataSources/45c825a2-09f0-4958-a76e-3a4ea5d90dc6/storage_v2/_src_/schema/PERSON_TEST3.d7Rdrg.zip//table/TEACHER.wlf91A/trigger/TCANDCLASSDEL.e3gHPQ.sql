create trigger TCANDCLASSDEL
    before delete
    on TEACHER
    for each row
begin
 delete from tc where teacher_id = :old.teacher_id;
 delete from class where instructor = :old.teacher_id;
 end;
/

