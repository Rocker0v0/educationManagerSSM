create trigger COURSES_ID_AUTOINCREMENT
    before insert
    on COURSES
    for each row
    when (new.course_id is null)
begin
 select course_id_sequence.nextval into: new.course_id from dual;
 end;
/

