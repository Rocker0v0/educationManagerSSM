create trigger DELSC
    before delete
    on TC
    for each row
begin
delete from SC where sc.id = :old.id;
end;
/

