create trigger TEACHERUSER
    after insert
    on TEACHER
    for each row
begin
 insert into tea_user values(:new.teacher_id,123456);
 end;
/

